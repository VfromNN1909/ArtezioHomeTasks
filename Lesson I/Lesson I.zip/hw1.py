# вводим строку с клавиатуры
S = input('Enter your string: ')

# выводим в верхнем регистре
print('Upper string: ', S.upper())
